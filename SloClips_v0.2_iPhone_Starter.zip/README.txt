SloClips_ Prototype v0.2

WHAT THIS VERSION DOES
- Responsive dark/purple clipping studio layout for iPhone and desktop.
- Select a local video from your device and preview it in the browser.
- Enter clip start/end times or set them from the current playhead.
- Save multiple moment markers in the current browser session.
- Preview caption text in a vertical 9:16 frame.

IMPORTANT LIMITATIONS
- This is a front-end prototype. It does not yet run AI moment detection, render/export trimmed MP4 clips, store uploads on a server, connect Twitch/YouTube/Kick accounts, or publish to social platforms.
- The selected video stays local in your browser session. Reloading or closing the page clears it.
- Only process videos you own or have permission to edit and repost.

PUBLISH FROM IPHONE
1. Open https://github.com/Elflakooo/SloClips in Safari.
2. Open index.html.
3. Tap the pencil/Edit button.
4. Replace the existing file contents with the contents of this index.html, or use Add file > Upload files to upload this index.html and confirm replacing the existing file.
5. Commit the changes to the main branch.
6. Wait for GitHub Pages to deploy, then refresh https://elflakooo.github.io/SloClips/.

If GitHub's mobile editor is difficult, use Safari > aA > Request Desktop Website.
