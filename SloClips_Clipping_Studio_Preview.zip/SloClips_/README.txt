SloClips_ — Clipping Studio preview

WHAT THIS IS
A responsive, single-page front-end preview for your SloClips_ project.

IMPORTANT
This is a visual prototype, not the full automated clipping application.
The sample metrics and AI moment suggestions are placeholders. Twitch, YouTube,
Kick, video processing, AI detection, and social publishing are not connected yet.
Use only videos you own or have permission to process and repost. Review clips
before publishing.

PREVIEW LOCALLY
1. Extract the ZIP.
2. Open the SloClips_ folder.
3. Double-click index.html. It opens in your browser.

PUBLISH WITH GITHUB PAGES
1. Sign in to GitHub and open https://github.com/Elflakooo/SloClips
2. Choose Add file > Upload files.
3. Upload index.html from this folder (README.txt is optional).
4. Commit the changes to the main branch.
5. Open Settings > Pages.
6. Under Build and deployment, choose Deploy from a branch.
7. Select main and /(root), then Save.
8. Wait for GitHub Pages to publish. The public site URL will appear in Settings > Pages.

You can change the design later. Keep the repository private until you are ready
for the site and its contents to be public.
